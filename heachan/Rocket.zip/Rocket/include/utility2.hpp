#ifndef UTILITY2_HPP
# define UTILITY2_HPP

# include "rocket/Rocket.hpp"
namespace utd2 {
    void one_ddalkak(Rocket &instance);
    void one_ddalkak(Rocket *instance);
    void one_ddalkak(Rocket **instance);
}
#endif