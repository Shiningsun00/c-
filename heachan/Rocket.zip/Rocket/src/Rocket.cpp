#include "rocket/Rocket.hpp"

Rocket::Rocket(void) : ARocket() {
    std::cout << "[Rocket] " << MSG_DCREATE << std::endl;
}

Rocket::Rocket(int y, float theta, int fuel_amount, float ignition_temp) 
    : ARocket(y, theta, fuel_amount, ignition_temp) {
	std::cout << "[Rocket] " << MSG_CREATE << MSG_CALL << MSG_ENDL;
}                                               // 생성자
Rocket::Rocket(const Rocket& obj)
    : ARocket(obj) {
	std::cout << MSG_COPY << MSG_CALL << MSG_ENDL;
    *this = obj;
}                                           // 복사생성자

Rocket& Rocket::operator=(const Rocket& obj){
    
    if (this == &obj) //
        return *this;
    std::cout << MSG_ASSIGN << MSG_CALL << MSG_ENDL;
    (*this).setY(obj.getY());
    (*this).setTheta(obj.getTheta());
    return *this;
}                                               // 복사 대입 연산자

Rocket::~Rocket(void){
    std::cout << MSG_DESTROY << MSG_CALL << MSG_ENDL;
    y = 0;
    theta = 0;
    launch = 0;
}                          // 소멸자

const std::string& Rocket::getFuelType(void){ return fuel_type; }