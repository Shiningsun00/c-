#include "utility.hpp"
#include "utility2.hpp"
#include "rocket/LiquidFuel.hpp"
#include "rocket/SoildFuel.hpp"



// void test1(void) {
//     Rocket heachan(20, 0.12); // Stack memory
//     std::cout << std::endl;
//     Rocket heachan2(20, 0.12);
//     std::cout << std::endl;
//     heachan2 = heachan;

//     std::cout << std::endl;
//     Rocket heachan3(heachan);


//     //TODO: 
//     std::cout << std::endl;
//     Rocket heachan4 = heachan;


//     // (*heachan).getLaunch()
//     // Rocket heachan2 = 


//     std::cout << heachan.getY() << ", ";
//     std::cout << heachan.getLaunch() << ", ";
//     std::cout << heachan.getTheta() << std::endl;

    
//     /* --------------- */


//     // one_ddalkak(heachan);
//     Rocket* heachan_ptr = &heachan;

//     utd1::one_ddalkak(heachan);
//     utd1::one_ddalkak(&heachan);
//     utd1::one_ddalkak(&heachan_ptr);

//     utd2::one_ddalkak(heachan);
//     utd2::one_ddalkak(&heachan);
//     utd2::one_ddalkak(&heachan_ptr);


//     /* --------------- */

//     std::cout << heachan.getY() << ", ";
//     std::cout << heachan.getLaunch() << ", ";
//     std::cout << heachan.getTheta() << std::endl;


//     heachan.setLaunch();
//     heachan.setTheta(45); // 예상 : 0.866
//     heachan.setY(4);

//     std::cout << heachan.getY() << ", ";
//     std::cout << heachan.getLaunch() << ", ";
//     std::cout << heachan.getTheta() << std::endl;

// }

static void test2(void) {
    LiquidFuel liquid_fuel;
    printValue(liquid_fuel.checkFuel());

    std::cout << std::endl;
    SolidFuel solid_fuel;
    printValue(solid_fuel.checkFuel());

    SolidFuel solid_fuel2(10, 4, 80, 250, 2);
    printValue(solid_fuel2.checkFuel());
}

static void test3(void) {
    // Rocket test_rocket();
    // Rocket test_rocket = Rocket();
    Rocket test_rocket;
    test_rocket.setIgnitionTemp(2000);
    printValue(test_rocket.getIgnitionTemp());
    printValue("\n");
    printValue("----------< Just >----------------");

    SolidFuel soli_rocket;
    soli_rocket.setIgnitionTemp(20);
    printValue(soli_rocket.getIgnitionTemp());
    printValue("\n");

    LiquidFuel liqu_rocket;
    liqu_rocket.setIgnitionTemp(20);
    printValue(liqu_rocket.getIgnitionTemp());
    printValue("\n");

    printValue("---------< 다형성 정적할당 >-------------------");

    // Rocket any_rocket = Soli_rocket(); // => 공간이 작아서 다 안들어감
    // Rocket& any_rocket = Soli_rocket(); // => stack 내가 없어서
    Rocket& any_rocket = soli_rocket;   // => 그래서 정적할당에서는 이렇게 밖에 못함 
    any_rocket.setIgnitionTemp(10);
    printValue(any_rocket.getIgnitionTemp());
    printValue("\n");

    Rocket& any_rocket2 = liqu_rocket;
    any_rocket2.setIgnitionTemp(10);
    printValue(any_rocket2.getIgnitionTemp());
    printValue("\n");

    printValue("---------< 다형성 동적할당 >-------------------");

    // 근데, 동적할당 이게 가능함
    Rocket* any_rocket_ptr = new SolidFuel();
    (*any_rocket_ptr).setIgnitionTemp(10);
    printValue((*any_rocket_ptr).getIgnitionTemp());
    printValue("\n");

    Rocket* any_rocket_ptr2 = new SolidFuel();
    any_rocket_ptr2->setIgnitionTemp(10);
    printValue(any_rocket_ptr2->getIgnitionTemp());
    printValue("\n");

    Rocket** any_rocket_double_ptr = &any_rocket_ptr;
    (**any_rocket_double_ptr).setIgnitionTemp(10);
    (*any_rocket_double_ptr)->setIgnitionTemp(10);
    printValue((*any_rocket_double_ptr)->getIgnitionTemp());

    delete any_rocket_ptr;
    delete any_rocket_ptr2;

    // system("leaks -q rocket"); // unix 계열
    //+>  flag      -fsanitize=leak 

    /*
    printValue("---------< check >-------------------");

    for (size_t i = 0; i < 2 ; ++i) {
        printValue(any_rocket[i].getIgnitionTemp());
    }
    */

}

// static void test3(void) { 
//     std::cout << "Hello" << std::endl;
// }



/**
 * 원래 redifition이 안된다.
 * 근데, 부모 자식간에는 된다.
 * 여기서 자기 클래스대로 선언하고 사용하면 괜찮지만,
 * 반복문이나 간소화를 위해서 부모클래스에 업캐스팅을 하게 되면, 
 * 자기 자신의 함수를 잃어버리고, 부모 함수를 실행하게 된다.
 * 그래서 부모 함수에 virtual 키워드를 넣어서 자식 클래스들의 함수를 찾아갈 수 있또록 하는 것이
 * "overriding" 이다.
 */


static void test4(void) {

    std::cout << "1" << std::endl;
    Rocket rocket;
    printValue(rocket.getFuelType());

    std::cout << "2" << std::endl;
    SolidFuel solid_rocket;
    printValue(solid_rocket.getFuelType());

    std::cout << "3" << std::endl;
    LiquidFuel liquid_rocket;
    printValue(liquid_rocket.getFuelType());


    // ARocket a_rocket;


}




    

int main(void) {
    // test1();
    // test2();
    // test3();

    test4();
    
    return 0;
}
    // int num = 30;

    // int* num_ptr = &num;

    // int& num_ref = num;
    // int& angle = num;

    // num_ref = 50;
    // angle = 1;
    // num = 30;

    // std::cout << num_ref << std::endl;
    // std::cout << num << std::endl;
    // std::cout << angle << std::endl;